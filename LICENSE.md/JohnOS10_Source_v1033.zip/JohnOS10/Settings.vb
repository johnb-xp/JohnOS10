﻿Public Class Settings
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
    End Sub

    Private Sub Panel2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel2.MouseDown
        If e.Button = MouseButtons.Left Then
            Me.Panel2.Capture = False
            Const WM_NCLBUTTONDOWN As Integer = &HA1S
            Const HTCAPTION As Integer = 2
            Dim msg As Message =
            Message.Create(Me.Handle, WM_NCLBUTTONDOWN,
                New IntPtr(HTCAPTION), IntPtr.Zero)
            Me.DefWndProc(msg)
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'SET PROGESSBAR TO THE PERFORMANCE VALUE.
        pbCPU.Value = pcCPU.NextValue
        pbRAM.Value = pcRAM.NextValue
        'SET THE LABEL TO PROGRESS BAR VALUE.
        lblCPU.Text = "CPU: " & pbCPU.Value & "%"
        lblRAM.Text = "RAM: " & pbRAM.Value & "%"
    End Sub

    Private Sub Settings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'SET THE INTERVAL TO 500.
        Timer1.Interval = 500
        'START THE TIMER 
        Timer1.Start()
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles setBackground.Click
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub updateIcon_Click(sender As Object, e As EventArgs) Handles updateIcon.Click
        UpdateJOS.Show()
    End Sub

    Private Sub updateLabel_Click(sender As Object, e As EventArgs) Handles updateLabel.Click
        UpdateJOS.Show()
    End Sub

    Private Sub aboutIcon_Click(sender As Object, e As EventArgs) Handles aboutIcon.Click
        AboutJohnOS.Show()
    End Sub

    Private Sub aboutLabel_Click(sender As Object, e As EventArgs) Handles aboutLabel.Click
        AboutJohnOS.Show()
    End Sub

    Private Sub networkIcon_Click(sender As Object, e As EventArgs) Handles networkIcon.Click
        NetworkDiagnostic.Show()
    End Sub

    Private Sub diagnosticLabel_Click(sender As Object, e As EventArgs) Handles diagnosticLabel.Click
        NetworkDiagnostic.Show()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Desktop.BackgroundImage = My.Resources.default_wall
    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As System.Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        Desktop.BackgroundImage = Image.FromFile(OpenFileDialog1.FileName)
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        Desktop.BackgroundImage = My.Resources.default_wall
    End Sub
End Class