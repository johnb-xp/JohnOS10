﻿Public Class Desktop

    Private Sub startbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles startbutton.Click
        startmenu.Visible = True
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
    End Sub

    Private Sub notepadbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles notepadbutton.Click
        Notepad.Show()
        startmenu.Visible = False
    End Sub

    Private Sub closemenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closemenu.Click
        startmenu.Visible = False
    End Sub

    Private Sub browser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles browserbutton.Click
        Browser.Show()
        startmenu.Visible = False
    End Sub

    Private Sub update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JOSupdate.Click
        UpdateJOS.show()
        startmenu.Visible = False
    End Sub

    Private Sub shutdown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles shutdown.Click
        Application.Exit()

    End Sub
End Class
