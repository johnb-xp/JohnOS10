﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Desktop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Desktop))
        Me.taskbar = New System.Windows.Forms.Panel()
        Me.startbutton = New System.Windows.Forms.Button()
        Me.startmenu = New System.Windows.Forms.Panel()
        Me.shutdown = New System.Windows.Forms.Button()
        Me.JOSupdate = New System.Windows.Forms.Button()
        Me.notepadbutton = New System.Windows.Forms.Button()
        Me.browserbutton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.closemenu = New System.Windows.Forms.Button()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.taskbar.SuspendLayout()
        Me.startmenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'taskbar
        '
        Me.taskbar.Controls.Add(Me.startbutton)
        Me.taskbar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.taskbar.Location = New System.Drawing.Point(0, 502)
        Me.taskbar.Name = "taskbar"
        Me.taskbar.Size = New System.Drawing.Size(662, 23)
        Me.taskbar.TabIndex = 0
        '
        'startbutton
        '
        Me.startbutton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.startbutton.Location = New System.Drawing.Point(0, -1)
        Me.startbutton.Name = "startbutton"
        Me.startbutton.Size = New System.Drawing.Size(75, 23)
        Me.startbutton.TabIndex = 0
        Me.startbutton.Text = "Start"
        Me.startbutton.UseVisualStyleBackColor = True
        '
        'startmenu
        '
        Me.startmenu.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.startmenu.Controls.Add(Me.shutdown)
        Me.startmenu.Controls.Add(Me.JOSupdate)
        Me.startmenu.Controls.Add(Me.notepadbutton)
        Me.startmenu.Controls.Add(Me.browserbutton)
        Me.startmenu.Controls.Add(Me.Label1)
        Me.startmenu.Controls.Add(Me.closemenu)
        Me.startmenu.Controls.Add(Me.ShapeContainer1)
        Me.startmenu.Location = New System.Drawing.Point(0, 276)
        Me.startmenu.Name = "startmenu"
        Me.startmenu.Size = New System.Drawing.Size(200, 226)
        Me.startmenu.TabIndex = 1
        Me.startmenu.Visible = False
        '
        'shutdown
        '
        Me.shutdown.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.shutdown.Location = New System.Drawing.Point(0, 187)
        Me.shutdown.Name = "shutdown"
        Me.shutdown.Size = New System.Drawing.Size(200, 36)
        Me.shutdown.TabIndex = 6
        Me.shutdown.Text = "Shutdown JohnOS"
        Me.shutdown.UseVisualStyleBackColor = True
        '
        'JOSupdate
        '
        Me.JOSupdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.JOSupdate.Location = New System.Drawing.Point(0, 148)
        Me.JOSupdate.Name = "JOSupdate"
        Me.JOSupdate.Size = New System.Drawing.Size(200, 36)
        Me.JOSupdate.TabIndex = 5
        Me.JOSupdate.Text = "JohnOS Update"
        Me.JOSupdate.UseVisualStyleBackColor = True
        '
        'notepadbutton
        '
        Me.notepadbutton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.notepadbutton.Location = New System.Drawing.Point(0, 110)
        Me.notepadbutton.Name = "notepadbutton"
        Me.notepadbutton.Size = New System.Drawing.Size(200, 36)
        Me.notepadbutton.TabIndex = 4
        Me.notepadbutton.Text = "JohnOS Notepad"
        Me.notepadbutton.UseVisualStyleBackColor = True
        '
        'browserbutton
        '
        Me.browserbutton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.browserbutton.Location = New System.Drawing.Point(0, 72)
        Me.browserbutton.Name = "browserbutton"
        Me.browserbutton.Size = New System.Drawing.Size(200, 36)
        Me.browserbutton.TabIndex = 3
        Me.browserbutton.Text = "JohnOS Browser"
        Me.browserbutton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.GhostWhite
        Me.Label1.Location = New System.Drawing.Point(2, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "JohnOS 10"
        '
        'closemenu
        '
        Me.closemenu.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closemenu.Location = New System.Drawing.Point(0, 34)
        Me.closemenu.Name = "closemenu"
        Me.closemenu.Size = New System.Drawing.Size(200, 36)
        Me.closemenu.TabIndex = 0
        Me.closemenu.Text = "Close the Start Menu"
        Me.closemenu.UseVisualStyleBackColor = True
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(200, 226)
        Me.ShapeContainer1.TabIndex = 1
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderColor = System.Drawing.Color.DarkGray
        Me.RectangleShape1.FillColor = System.Drawing.Color.DarkBlue
        Me.RectangleShape1.FillGradientColor = System.Drawing.Color.Blue
        Me.RectangleShape1.FillGradientStyle = Microsoft.VisualBasic.PowerPacks.FillGradientStyle.Horizontal
        Me.RectangleShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid
        Me.RectangleShape1.Location = New System.Drawing.Point(-1, 0)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(199, 33)
        '
        'Desktop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(662, 525)
        Me.Controls.Add(Me.startmenu)
        Me.Controls.Add(Me.taskbar)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Desktop"
        Me.Text = "Desktop"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.taskbar.ResumeLayout(False)
        Me.startmenu.ResumeLayout(False)
        Me.startmenu.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents taskbar As System.Windows.Forms.Panel
    Friend WithEvents startbutton As System.Windows.Forms.Button
    Friend WithEvents startmenu As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents closemenu As System.Windows.Forms.Button
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents shutdown As System.Windows.Forms.Button
    Friend WithEvents JOSupdate As System.Windows.Forms.Button
    Friend WithEvents notepadbutton As System.Windows.Forms.Button
    Friend WithEvents browserbutton As System.Windows.Forms.Button

End Class
