﻿Public Class Desktop

    Private Sub Desktop_Click(sender As System.Object, e As System.EventArgs) Handles Me.Click
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub IE_Icon_Click(sender As System.Object, e As System.EventArgs) Handles IE_Icon.Click
        Browser.Show()
    End Sub

    Private Sub Label2_Click(sender As System.Object, e As System.EventArgs) Handles Label2.Click
        Browser.Show()
    End Sub

    Private Sub Notepad_Icon_Click(sender As System.Object, e As System.EventArgs) Handles Notepad_Icon.Click
        Notepad.Show()
    End Sub

    Private Sub Label3_Click(sender As System.Object, e As System.EventArgs) Handles Label3.Click
        Notepad.Show()
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        Browser.Show()
        allprogs.Hide()
        startmenu.Hide()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Notepad.Show()
        allprogs.Hide()
        startmenu.Hide()
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        Settings.Show()
        allprogs.Hide()
        startmenu.Hide()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        allprogs.Show()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Calendar.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Clock.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Calc.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        startmenu.Hide()
        allprogs.Hide()
        Dim frm As New BitcoinPrice()
        BitcoinPrice.Show()
    End Sub
    Private Sub Shutdown_Click(sender As System.Object, e As System.EventArgs) Handles ShutdownButton.Click
        Shutdown.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub startbutton_Click(sender As System.Object, e As System.EventArgs) Handles startbutton.Click
        startmenu.Show()
    End Sub
    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Minesweeper.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub PictureBox5_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox5.Click
        allprogs.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox1.Click
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub PictureBox2_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox2.Click
        Browser.Show()
        startmenu.Hide()
    End Sub

    Private Sub PictureBox3_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox3.Click
        Notepad.Show()
        startmenu.Hide()
    End Sub

    Private Sub PictureBox4_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox4.Click
        Settings.Show()
        startmenu.Hide()
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        UpdateJOS.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button12_Click(sender As System.Object, e As System.EventArgs) Handles Button12.Click
        Browser.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button13_Click(sender As System.Object, e As System.EventArgs) Handles Button13.Click
        Notepad.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button14_Click(sender As System.Object, e As System.EventArgs) Handles Button14.Click
        Settings.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub PictureBox8_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox8.Click
        JohnOSFileManage.Show()
    End Sub

    Private Sub Button15_Click(sender As System.Object, e As System.EventArgs) Handles Button15.Click
        Yortzee.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button16_Click(sender As System.Object, e As System.EventArgs) Handles Button16.Click
        JIM.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button17_Click(sender As System.Object, e As System.EventArgs) Handles Button17.Click
        MoonPhase.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button18_Click(sender As System.Object, e As System.EventArgs) Handles Button18.Click
        MediaPlayer.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub PictureBox6_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox6.Click
        Me.Close()
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        allprogs.Hide()
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        RadioMarg.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        Maps.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        Launcher.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        Launcher.Show()
        startmenu.Hide()
        allprogs.Hide()
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Calendar.Show()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles taskbarClockTimer.Tick
        Label6.Text = DateTime.Now.ToString("hh:mm tt")
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs)
        startmenu.Show()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        NetworkDiagnostic.Show()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles refreshJIS.Tick
        Try
            PictureBox10.ImageLocation = "http://web.johnbilkey.cf:8080/johnos/josconnect.png"
        Catch
            PictureBox10.Image = My.Resources.nojos
        End Try
    End Sub

    Private Sub taskbar_Paint(sender As Object, e As PaintEventArgs) Handles taskbar.Paint
        Try
            PictureBox10.ImageLocation = "http://web.johnbilkey.cf:8080/johnos/josconnect.png"
        Catch
            PictureBox10.Image = My.Resources.nojos
        End Try
    End Sub
End Class