﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Settings))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.backgroundLabel = New System.Windows.Forms.Label()
        Me.setBackground = New System.Windows.Forms.PictureBox()
        Me.pbRAM = New System.Windows.Forms.ProgressBar()
        Me.pbCPU = New System.Windows.Forms.ProgressBar()
        Me.lblRAM = New System.Windows.Forms.Label()
        Me.lblCPU = New System.Windows.Forms.Label()
        Me.diagnosticLabel = New System.Windows.Forms.Label()
        Me.networkIcon = New System.Windows.Forms.PictureBox()
        Me.aboutLabel = New System.Windows.Forms.Label()
        Me.updateIcon = New System.Windows.Forms.PictureBox()
        Me.aboutIcon = New System.Windows.Forms.PictureBox()
        Me.updateLabel = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pcCPU = New System.Diagnostics.PerformanceCounter()
        Me.pcRAM = New System.Diagnostics.PerformanceCounter()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.setBackground, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.networkIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.updateIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.aboutIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.pcCPU, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcRAM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.IndianRed
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(541, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(21, 21)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "X"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.backgroundLabel)
        Me.Panel1.Controls.Add(Me.setBackground)
        Me.Panel1.Controls.Add(Me.pbRAM)
        Me.Panel1.Controls.Add(Me.pbCPU)
        Me.Panel1.Controls.Add(Me.lblRAM)
        Me.Panel1.Controls.Add(Me.lblCPU)
        Me.Panel1.Controls.Add(Me.diagnosticLabel)
        Me.Panel1.Controls.Add(Me.networkIcon)
        Me.Panel1.Controls.Add(Me.aboutLabel)
        Me.Panel1.Controls.Add(Me.updateIcon)
        Me.Panel1.Controls.Add(Me.aboutIcon)
        Me.Panel1.Controls.Add(Me.updateLabel)
        Me.Panel1.Location = New System.Drawing.Point(2, 27)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(562, 388)
        Me.Panel1.TabIndex = 5
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(469, 7)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox4.TabIndex = 31
        Me.PictureBox4.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(443, 63)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Default Background"
        '
        'backgroundLabel
        '
        Me.backgroundLabel.AutoSize = True
        Me.backgroundLabel.Location = New System.Drawing.Point(317, 63)
        Me.backgroundLabel.Name = "backgroundLabel"
        Me.backgroundLabel.Size = New System.Drawing.Size(103, 13)
        Me.backgroundLabel.TabIndex = 29
        Me.backgroundLabel.Text = "Custom Background"
        '
        'setBackground
        '
        Me.setBackground.Image = CType(resources.GetObject("setBackground.Image"), System.Drawing.Image)
        Me.setBackground.Location = New System.Drawing.Point(340, 7)
        Me.setBackground.Name = "setBackground"
        Me.setBackground.Size = New System.Drawing.Size(48, 48)
        Me.setBackground.TabIndex = 28
        Me.setBackground.TabStop = False
        '
        'pbRAM
        '
        Me.pbRAM.Location = New System.Drawing.Point(383, 357)
        Me.pbRAM.Name = "pbRAM"
        Me.pbRAM.Size = New System.Drawing.Size(169, 23)
        Me.pbRAM.TabIndex = 27
        '
        'pbCPU
        '
        Me.pbCPU.Location = New System.Drawing.Point(383, 328)
        Me.pbCPU.Name = "pbCPU"
        Me.pbCPU.Size = New System.Drawing.Size(169, 23)
        Me.pbCPU.TabIndex = 26
        '
        'lblRAM
        '
        Me.lblRAM.AutoSize = True
        Me.lblRAM.Location = New System.Drawing.Point(328, 367)
        Me.lblRAM.Name = "lblRAM"
        Me.lblRAM.Size = New System.Drawing.Size(31, 13)
        Me.lblRAM.TabIndex = 25
        Me.lblRAM.Text = "RAM"
        '
        'lblCPU
        '
        Me.lblCPU.AutoSize = True
        Me.lblCPU.Location = New System.Drawing.Point(328, 338)
        Me.lblCPU.Name = "lblCPU"
        Me.lblCPU.Size = New System.Drawing.Size(29, 13)
        Me.lblCPU.TabIndex = 24
        Me.lblCPU.Text = "CPU"
        '
        'diagnosticLabel
        '
        Me.diagnosticLabel.AutoSize = True
        Me.diagnosticLabel.Location = New System.Drawing.Point(199, 63)
        Me.diagnosticLabel.Name = "diagnosticLabel"
        Me.diagnosticLabel.Size = New System.Drawing.Size(100, 13)
        Me.diagnosticLabel.TabIndex = 23
        Me.diagnosticLabel.Text = "Network Diagnostic"
        '
        'networkIcon
        '
        Me.networkIcon.Image = CType(resources.GetObject("networkIcon.Image"), System.Drawing.Image)
        Me.networkIcon.Location = New System.Drawing.Point(220, 7)
        Me.networkIcon.Name = "networkIcon"
        Me.networkIcon.Size = New System.Drawing.Size(48, 48)
        Me.networkIcon.TabIndex = 22
        Me.networkIcon.TabStop = False
        '
        'aboutLabel
        '
        Me.aboutLabel.AutoSize = True
        Me.aboutLabel.Location = New System.Drawing.Point(102, 63)
        Me.aboutLabel.Name = "aboutLabel"
        Me.aboutLabel.Size = New System.Drawing.Size(76, 13)
        Me.aboutLabel.TabIndex = 21
        Me.aboutLabel.Text = "About JohnOS"
        '
        'updateIcon
        '
        Me.updateIcon.Image = CType(resources.GetObject("updateIcon.Image"), System.Drawing.Image)
        Me.updateIcon.Location = New System.Drawing.Point(23, 7)
        Me.updateIcon.Name = "updateIcon"
        Me.updateIcon.Size = New System.Drawing.Size(48, 48)
        Me.updateIcon.TabIndex = 18
        Me.updateIcon.TabStop = False
        '
        'aboutIcon
        '
        Me.aboutIcon.Image = CType(resources.GetObject("aboutIcon.Image"), System.Drawing.Image)
        Me.aboutIcon.Location = New System.Drawing.Point(115, 7)
        Me.aboutIcon.Name = "aboutIcon"
        Me.aboutIcon.Size = New System.Drawing.Size(48, 48)
        Me.aboutIcon.TabIndex = 20
        Me.aboutIcon.TabStop = False
        '
        'updateLabel
        '
        Me.updateLabel.AutoSize = True
        Me.updateLabel.Location = New System.Drawing.Point(7, 63)
        Me.updateLabel.Name = "updateLabel"
        Me.updateLabel.Size = New System.Drawing.Size(83, 13)
        Me.updateLabel.TabIndex = 19
        Me.updateLabel.Text = "JohnOS Update"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(201, 90)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Network Diagnostic"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(112, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "About JohnOS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "JohnOS Update"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Location = New System.Drawing.Point(1, 1)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(563, 26)
        Me.Panel2.TabIndex = 11
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(515, 2)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(21, 21)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "-"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Location = New System.Drawing.Point(3, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Control Panel"
        '
        'pcCPU
        '
        Me.pcCPU.CategoryName = "Processor"
        Me.pcCPU.CounterName = "% Processor Time"
        Me.pcCPU.InstanceName = "_Total"
        '
        'pcRAM
        '
        Me.pcRAM.CategoryName = "Memory"
        Me.pcRAM.CounterName = "% Committed Bytes In Use"
        '
        'Timer1
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "Image Files (*.bmp;*.jpg;*.jpeg,*.png)|*.BMP;*.JPG;*.JPEG;*.PNG"
        Me.OpenFileDialog1.Title = "Choose an Image"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(30, 34)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(227, 34)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox3.TabIndex = 16
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(129, 34)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox2.TabIndex = 14
        Me.PictureBox2.TabStop = False
        '
        'Settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(566, 417)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Settings"
        Me.Text = "Control Panel"
        Me.TopMost = True
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.setBackground, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.networkIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.updateIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.aboutIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.pcCPU, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcRAM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents diagnosticLabel As Label
    Friend WithEvents networkIcon As PictureBox
    Friend WithEvents aboutLabel As Label
    Friend WithEvents updateIcon As PictureBox
    Friend WithEvents aboutIcon As PictureBox
    Friend WithEvents updateLabel As Label
    Friend WithEvents pbRAM As ProgressBar
    Friend WithEvents pbCPU As ProgressBar
    Friend WithEvents lblRAM As Label
    Friend WithEvents lblCPU As Label
    Friend WithEvents pcCPU As PerformanceCounter
    Friend WithEvents pcRAM As PerformanceCounter
    Friend WithEvents Timer1 As Timer
    Friend WithEvents backgroundLabel As Label
    Friend WithEvents setBackground As PictureBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label5 As Label
End Class
