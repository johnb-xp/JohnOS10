﻿Public Class Desktop

    Private Sub ComputerIcon_Click(sender As Object, e As EventArgs) Handles ComputerIcon.Click
        FileManager.Show()
    End Sub

    Private Sub ComputerLabel_Click(sender As Object, e As EventArgs) Handles computerLabel.Click
        FileManager.Show()
    End Sub

    Private Sub BrowserLabel_Click(sender As Object, e As EventArgs) Handles browserLabel.Click
        Browser.Show()
    End Sub

    Private Sub IE_Icon_Click(sender As System.Object, e As System.EventArgs) Handles IE_Icon.Click
        Browser.Show()
    End Sub

    Private Sub Notepad_Icon_Click(sender As System.Object, e As System.EventArgs) Handles Notepad_Icon.Click
        Notepad.Show()
    End Sub

    Private Sub NotepadLabel_Click(sender As Object, e As EventArgs) Handles notepadLabel.Click
        Notepad.Show()
    End Sub

    Private Sub Startbutton_Click(sender As System.Object, e As System.EventArgs) Handles startbutton.Click
        If StartMenu.Visible Then
            StartMenu.Hide()
            allPrograms.Hide()
        Else
            StartMenu.Show()
        End If
    End Sub
    Private Sub TaskbarClock_Click(sender As Object, e As EventArgs) Handles taskbarClockLabel.Click
        Calendar.Show()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles taskbarClockTimer.Tick
        taskbarClockLabel.Text = DateTime.Now.ToString("hh:mm tt")
    End Sub

    Private Sub NetworkIcon_Click(sender As Object, e As EventArgs) Handles networkIcon.Click
        NetworkDiagnostic.Show()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles refreshJIS.Tick
        Try
            networkIcon.ImageLocation = "http://johnbilkey.cf/johnos/josconnect.png"
        Catch
            networkIcon.Image = My.Resources.nojos
        End Try
    End Sub

    Private Sub Taskbar_Paint(sender As Object, e As PaintEventArgs) Handles taskbar.Paint
        networkIcon.Hide()
        Try
            networkIcon.ImageLocation = "http://johnbilkey.cf/johnos/josconnect.png"
        Catch
            networkIcon.Image = My.Resources.nojos
        End Try
        networkIcon.Show()
    End Sub

    Private Sub StartButtonIcon_Click(sender As Object, e As EventArgs) Handles startButtonIcon.Click
        If StartMenu.Visible Then
            StartMenu.Hide()
            allPrograms.Hide()

        Else
            StartMenu.Show()
        End If
    End Sub

    Private Sub radioMiniPlayer_Click(sender As Object, e As EventArgs) Handles radioMiniPlayer.Click
        RadioMarg.Show()
        radioMiniPlayer.Hide()

    End Sub

    Private Sub miniPlayer_Click(sender As Object, e As EventArgs) Handles miniPlayer.Click
        MediaPlayer.Show()
        miniPlayer.Hide()

    End Sub

    Private Sub Desktop_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        allPrograms.GoHome()
        StartMenu.GoHome()
        If Not My.Settings.FirstRun Then
            Me.BackgroundImageLayout = My.Settings.BackgroundImageLayout
            Me.BackgroundImage = DisplaySettings.GetImageFromString(My.Settings.BackgroundImage)
        Else
            Me.BackgroundImage = My.Resources.default_wall
            Me.BackgroundImageLayout = 3
            My.Settings.BackgroundImage = DisplaySettings.GetStringFromImage(Me.BackgroundImage)
            My.Settings.BackgroundImageLayout = Me.BackgroundImageLayout
            My.Settings.Save()
            Welcome.Run()
        End If

    End Sub

    Private Sub MinimizedButton_Click(sender As Object, e As EventArgs)

    End Sub
End Class