﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Browser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Browser))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.maxButton = New System.Windows.Forms.Button()
        Me.minButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.closeButton = New System.Windows.Forms.Button()
        Me.backButton = New System.Windows.Forms.Button()
        Me.urlBar = New System.Windows.Forms.TextBox()
        Me.goButton = New System.Windows.Forms.Button()
        Me.forwardButton = New System.Windows.Forms.Button()
        Me.refreshButton = New System.Windows.Forms.Button()
        Me.informationButton = New System.Windows.Forms.Button()
        Me.homeButton = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.maxButton)
        Me.Panel1.Controls.Add(Me.minButton)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.closeButton)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(974, 26)
        Me.Panel1.TabIndex = 1
        '
        'maxButton
        '
        Me.maxButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.maxButton.BackColor = System.Drawing.Color.DodgerBlue
        Me.maxButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.maxButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.maxButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maxButton.ForeColor = System.Drawing.Color.White
        Me.maxButton.Location = New System.Drawing.Point(926, 2)
        Me.maxButton.Name = "maxButton"
        Me.maxButton.Size = New System.Drawing.Size(21, 22)
        Me.maxButton.TabIndex = 14
        Me.maxButton.Text = "🗗"
        Me.maxButton.UseVisualStyleBackColor = False
        '
        'minButton
        '
        Me.minButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.minButton.BackColor = System.Drawing.Color.DodgerBlue
        Me.minButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.minButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.minButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minButton.ForeColor = System.Drawing.Color.White
        Me.minButton.Location = New System.Drawing.Point(901, 2)
        Me.minButton.Name = "minButton"
        Me.minButton.Size = New System.Drawing.Size(21, 22)
        Me.minButton.TabIndex = 13
        Me.minButton.Text = "-"
        Me.minButton.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Trebuchet MS", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Location = New System.Drawing.Point(6, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "JohnOS Browser"
        '
        'closeButton
        '
        Me.closeButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.closeButton.BackColor = System.Drawing.Color.IndianRed
        Me.closeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.closeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.closeButton.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeButton.ForeColor = System.Drawing.Color.White
        Me.closeButton.Location = New System.Drawing.Point(952, 2)
        Me.closeButton.Name = "closeButton"
        Me.closeButton.Size = New System.Drawing.Size(20, 22)
        Me.closeButton.TabIndex = 0
        Me.closeButton.Text = "X"
        Me.closeButton.UseVisualStyleBackColor = False
        '
        'backButton
        '
        Me.backButton.BackColor = System.Drawing.Color.Transparent
        Me.backButton.BackgroundImage = CType(resources.GetObject("backButton.BackgroundImage"), System.Drawing.Image)
        Me.backButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.backButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.backButton.Font = New System.Drawing.Font("Webdings", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.backButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.backButton.Location = New System.Drawing.Point(0, 28)
        Me.backButton.Name = "backButton"
        Me.backButton.Size = New System.Drawing.Size(27, 27)
        Me.backButton.TabIndex = 2
        Me.backButton.UseVisualStyleBackColor = False
        '
        'urlBar
        '
        Me.urlBar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.urlBar.Location = New System.Drawing.Point(147, 32)
        Me.urlBar.Name = "urlBar"
        Me.urlBar.Size = New System.Drawing.Size(790, 20)
        Me.urlBar.TabIndex = 6
        Me.urlBar.Text = "http://johnbilkey.cf/johnos/"
        '
        'goButton
        '
        Me.goButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.goButton.BackColor = System.Drawing.Color.Transparent
        Me.goButton.BackgroundImage = CType(resources.GetObject("goButton.BackgroundImage"), System.Drawing.Image)
        Me.goButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.goButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.goButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.goButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.goButton.Location = New System.Drawing.Point(940, 27)
        Me.goButton.Name = "goButton"
        Me.goButton.Size = New System.Drawing.Size(31, 28)
        Me.goButton.TabIndex = 7
        Me.goButton.UseVisualStyleBackColor = False
        '
        'forwardButton
        '
        Me.forwardButton.BackColor = System.Drawing.Color.Transparent
        Me.forwardButton.BackgroundImage = CType(resources.GetObject("forwardButton.BackgroundImage"), System.Drawing.Image)
        Me.forwardButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.forwardButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.forwardButton.Font = New System.Drawing.Font("Webdings", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.forwardButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.forwardButton.Location = New System.Drawing.Point(28, 28)
        Me.forwardButton.Name = "forwardButton"
        Me.forwardButton.Size = New System.Drawing.Size(27, 27)
        Me.forwardButton.TabIndex = 8
        Me.forwardButton.UseVisualStyleBackColor = False
        '
        'refreshButton
        '
        Me.refreshButton.BackColor = System.Drawing.Color.Transparent
        Me.refreshButton.BackgroundImage = CType(resources.GetObject("refreshButton.BackgroundImage"), System.Drawing.Image)
        Me.refreshButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.refreshButton.Font = New System.Drawing.Font("Webdings", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.refreshButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.refreshButton.Location = New System.Drawing.Point(57, 28)
        Me.refreshButton.Name = "refreshButton"
        Me.refreshButton.Size = New System.Drawing.Size(27, 27)
        Me.refreshButton.TabIndex = 9
        Me.refreshButton.UseVisualStyleBackColor = False
        '
        'informationButton
        '
        Me.informationButton.BackColor = System.Drawing.Color.Transparent
        Me.informationButton.BackgroundImage = CType(resources.GetObject("informationButton.BackgroundImage"), System.Drawing.Image)
        Me.informationButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.informationButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.informationButton.Font = New System.Drawing.Font("Webdings", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.informationButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.informationButton.Location = New System.Drawing.Point(117, 28)
        Me.informationButton.Name = "informationButton"
        Me.informationButton.Size = New System.Drawing.Size(27, 27)
        Me.informationButton.TabIndex = 11
        Me.informationButton.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.informationButton.UseVisualStyleBackColor = False
        '
        'homeButton
        '
        Me.homeButton.BackColor = System.Drawing.Color.Transparent
        Me.homeButton.BackgroundImage = CType(resources.GetObject("homeButton.BackgroundImage"), System.Drawing.Image)
        Me.homeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.homeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.homeButton.Font = New System.Drawing.Font("Webdings", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.homeButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.homeButton.Location = New System.Drawing.Point(88, 28)
        Me.homeButton.Name = "homeButton"
        Me.homeButton.Size = New System.Drawing.Size(27, 27)
        Me.homeButton.TabIndex = 12
        Me.homeButton.UseVisualStyleBackColor = False
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 58)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(974, 606)
        Me.WebBrowser1.TabIndex = 13
        Me.WebBrowser1.Url = New System.Uri("http://johnbilkey.cf/johnos", System.UriKind.Absolute)
        '
        'Panel2
        '
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 26)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(974, 32)
        Me.Panel2.TabIndex = 14
        '
        'Browser
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(974, 664)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.homeButton)
        Me.Controls.Add(Me.backButton)
        Me.Controls.Add(Me.informationButton)
        Me.Controls.Add(Me.refreshButton)
        Me.Controls.Add(Me.forwardButton)
        Me.Controls.Add(Me.goButton)
        Me.Controls.Add(Me.urlBar)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Browser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Browser"
        Me.TopMost = True
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents closeButton As System.Windows.Forms.Button
    Friend WithEvents backButton As System.Windows.Forms.Button
    Friend WithEvents urlBar As System.Windows.Forms.TextBox
    Friend WithEvents goButton As System.Windows.Forms.Button
    Friend WithEvents forwardButton As System.Windows.Forms.Button
    Friend WithEvents refreshButton As System.Windows.Forms.Button
    Friend WithEvents informationButton As System.Windows.Forms.Button
    Friend WithEvents homeButton As System.Windows.Forms.Button
    Friend WithEvents minButton As Button
    Friend WithEvents maxButton As Button
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents Panel2 As Panel
End Class
