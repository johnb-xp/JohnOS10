﻿Public Class browserPatcher
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Panel2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel2.MouseDown
        If e.Button = MouseButtons.Left Then
            Me.Panel2.Capture = False
            Const WM_NCLBUTTONDOWN As Integer = &HA1S
            Const HTCAPTION As Integer = 2
            Dim msg As Message =
            Message.Create(Me.Handle, WM_NCLBUTTONDOWN,
                New IntPtr(HTCAPTION), IntPtr.Zero)
            Me.DefWndProc(msg)
        End If
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        textBox.Text = "Configuring your browser. This window will automatically close."
        Try
            Me.MaximumSize = Screen.PrimaryScreen.WorkingArea.Size
            Dim AppName As String = My.Application.Info.AssemblyName
            Dim VersionCode As Integer
            Dim Version As String = ""
            Dim ieVersion As Object = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Software\Microsoft\Internet Explorer").GetValue("svcUpdateVersion")
            If ieVersion Is Nothing Then
                ieVersion = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Software\Microsoft\Internet Explorer").GetValue("Version")
            End If
            If ieVersion IsNot Nothing Then
                Version = ieVersion.ToString.Substring(0, ieVersion.ToString.IndexOf("."c))
                Select Case Version
                    Case "7"
                        VersionCode = 7000
                    Case "8"
                        VersionCode = 8000
                    Case "9"
                        VersionCode = 9000
                    Case "10"
                        VersionCode = 10000
                    Case Else
                        If CInt(Version) >= 11 Then
                            VersionCode = 11000
                        Else
                            Throw New Exception("IE Version not supported")
                            exceptionBox.Text = "IE Version not supported"
                        End If
                End Select
            Else
                Throw New Exception("Registry Error")
                exceptionBox.Text = "Registry Error"

            End If
            'Check if the right emulation is set
            'if not, Set Emulation to highest level possible on the user machine
            Dim Root As String = "HKEY_CURRENT_USER\"
            Dim Key As String = "Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION"
            Dim CurrentSetting As String = CStr(Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Key).GetValue(AppName & ".exe"))
            If CurrentSetting Is Nothing OrElse CInt(CurrentSetting) <> VersionCode Then
                Microsoft.Win32.Registry.SetValue(Root & Key, AppName & ".exe", VersionCode)
                Microsoft.Win32.Registry.SetValue(Root & Key, AppName & ".vshost.exe", VersionCode)
            End If
            Me.Close()
            exceptionBox.Text = "No Detected Errors"

        Catch
            textBox.Text = "There was a problem reconfiguring your browser. You may have to upgrade your version of Internet Explorer, or your OS."
        End Try
    End Sub
End Class